# SubmitFormRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **string** |  | [optional] 
**process_definition_id** | **string** |  | [optional] 
**task_id** | **string** |  | [optional] 
**business_key** | **string** |  | [optional] 
**properties** | [**\Swagger\Client\Model\RestFormProperty[]**](RestFormProperty.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


