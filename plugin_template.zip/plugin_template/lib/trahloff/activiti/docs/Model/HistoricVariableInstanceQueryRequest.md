# HistoricVariableInstanceQueryRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exclude_task_variables** | **bool** |  | [optional] [default to false]
**task_id** | **string** |  | [optional] 
**execution_id** | **string** |  | [optional] 
**process_instance_id** | **string** |  | [optional] 
**variable_name** | **string** |  | [optional] 
**variable_name_like** | **string** |  | [optional] 
**variables** | [**\Swagger\Client\Model\QueryVariable[]**](QueryVariable.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


