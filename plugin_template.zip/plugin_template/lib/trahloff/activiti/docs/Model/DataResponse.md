# DataResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **object** |  | [optional] 
**total** | **int** |  | [optional] 
**start** | **int** |  | [optional] 
**sort** | **string** |  | [optional] 
**order** | **string** |  | [optional] 
**size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


