# HistoricDetailQueryRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **int** |  | [optional] 
**size** | **int** |  | [optional] 
**sort** | **string** |  | [optional] 
**order** | **string** |  | [optional] 
**id** | **string** |  | [optional] 
**process_instance_id** | **string** |  | [optional] 
**execution_id** | **string** |  | [optional] 
**activity_instance_id** | **string** |  | [optional] 
**task_id** | **string** |  | [optional] 
**select_only_form_properties** | **bool** |  | [optional] [default to false]
**select_only_variable_updates** | **bool** |  | [optional] [default to false]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


