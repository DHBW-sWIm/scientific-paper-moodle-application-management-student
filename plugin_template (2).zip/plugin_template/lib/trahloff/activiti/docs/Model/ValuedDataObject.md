# ValuedDataObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] 
**xml_row_number** | **int** |  | [optional] 
**xml_column_number** | **int** |  | [optional] 
**extension_elements** | [**map[string,\Swagger\Client\Model\ExtensionElement[]]**](array.md) |  | [optional] 
**attributes** | [**map[string,\Swagger\Client\Model\ExtensionAttribute[]]**](array.md) |  | [optional] 
**name** | **string** |  | [optional] 
**documentation** | **string** |  | [optional] 
**execution_listeners** | [**\Swagger\Client\Model\ActivitiListener[]**](ActivitiListener.md) |  | [optional] 
**item_subject_ref** | [**\Swagger\Client\Model\ItemDefinition**](ItemDefinition.md) |  | [optional] 
**value** | **object** |  | [optional] 
**type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


